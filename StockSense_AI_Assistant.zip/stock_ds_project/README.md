# 📈 StockSense AI — Full Data Science Project

> **A professional, end-to-end stock market data science platform built with Python, Streamlit, and real-time Yahoo Finance data.**

---

## 🚀 Quick Start

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Run the App
```bash
streamlit run app.py
```

The app opens at **http://localhost:8501**

---

## 🗂️ Project Structure

```
stock_ds_project/
│
├── app.py                           ← Main entry point (Home page)
├── requirements.txt                 ← All Python dependencies
├── README.md                        ← This file
│
└── pages/
    ├── 1_📊_Stock_Explorer.py        ← Real-time OHLCV charts
    ├── 2_📉_Technical_Analysis.py    ← RSI, MACD, Bollinger, etc.
    ├── 3_🤖_ML_Prediction.py         ← RandomForest, GBM, Ridge ML models
    ├── 4_📰_Sentiment_Analysis.py    ← News sentiment + price correlation
    ├── 5_💼_Portfolio_Optimizer.py   ← Markowitz Efficient Frontier
    ├── 6_⚠️_Risk_Dashboard.py        ← VaR, CVaR, Drawdown, Beta, Monte Carlo
    ├── 7_🏢_Fundamental_Analysis.py  ← P/E, Revenue, Margins, Health Score
    ├── 8_🧪_Backtesting.py           ← Strategy backtesting engine
    └── 9_🌍_Market_Overview.py       ← Market pulse, sectors, screener
```

---

## 📖 Page-by-Page Explanation

### 🏠 Home (`app.py`)
- Entry dashboard showing live market indices (S&P 500, DJIA, NASDAQ, Bitcoin)
- Navigation overview for all 9 analysis modules
- Real-time price tickers from Yahoo Finance

---

### 📊 Page 1 — Stock Explorer
**What it does:** Interactive OHLCV price chart for any stock

**Key Concepts:**
- **OHLC** = Open, High, Low, Close — the 4 price points of each trading day
- **Candlestick Chart** = Each "candle" shows open/close as the body, high/low as wicks
  - 🟢 Green candle = price went UP (close > open)
  - 🔴 Red candle = price went DOWN (close < open)
- **Volume** = Number of shares traded — high volume = high conviction move
- **Moving Averages** = Smoothed price lines that filter out noise
- **Annualized Volatility** = Standard deviation of daily returns × √252 (trading days)

**Data Source:** Yahoo Finance via `yfinance` library

---

### 📉 Page 2 — Technical Analysis
**What it does:** Compute and visualize 7 professional trading indicators

**Indicators Explained:**

| Indicator | Formula | Signal |
|-----------|---------|--------|
| **RSI** (Relative Strength Index) | `100 - 100/(1 + avg_gain/avg_loss)` | >70 = Overbought 🔴, <30 = Oversold 🟢 |
| **MACD** | EMA(12) − EMA(26); Signal = EMA(9) | MACD > Signal = Bullish 🟢 |
| **Bollinger Bands** | MA ± 2×StdDev | Price near lower band = potential buy |
| **Stochastic %K** | `100 × (Close − Low_min)/(High_max − Low_min)` | >80 = Overbought, <20 = Oversold |
| **ATR** (Average True Range) | Rolling avg of max(H-L, H-PrevC, L-PrevC) | Measures volatility, not direction |
| **OBV** (On-Balance Volume) | Cumulative volume based on price direction | Divergence from price = reversal signal |
| **Williams %R** | `-100 × (High_max − Close)/(High_max − Low_min)` | Similar to Stochastic |

---

### 🤖 Page 3 — ML Price Prediction
**What it does:** Train machine learning models to predict next-day stock prices

**Feature Engineering:**
- Returns over 1, 5, 10, 21 days
- Moving average ratios (price/MA)
- 10-day and 20-day rolling volatility
- RSI, MACD, MACD Signal
- Bollinger Band width
- Volume ratio (current vs 10-day MA)
- High/Low ratio, Close/Open ratio

**Models Used:**

| Model | Strengths | Weaknesses |
|-------|-----------|------------|
| **Random Forest** | Handles non-linearity, robust | Slow for large data |
| **Gradient Boosting** | Often best accuracy | Can overfit |
| **Ridge Regression** | Fast, interpretable | Linear only |

**Metrics:**
- **R²** (R-squared): How well model explains variance (1.0 = perfect)
- **MAE** (Mean Absolute Error): Average dollar prediction error
- **RMSE** (Root Mean Squared Error): Punishes large errors more
- **MAPE** (Mean Absolute Percentage Error): Error as % of actual price

⚠️ **Note:** Predicting stock prices is notoriously hard. These models are for education, not trading!

---

### 📰 Page 4 — Sentiment Analysis
**What it does:** Correlate news sentiment with stock price movement

**How Sentiment Works:**
- Each trading day gets a sentiment score from −1 (very bearish) to +1 (very bullish)
- Score is calculated from news headlines using NLP techniques
- We then correlate sentiment with the NEXT day's return to find predictive power

**Production Integration (replace simulation with):**
- **NewsAPI** → Free tier: 100 requests/day
- **Alpha Vantage News API** → Built-in sentiment scores
- **Finnhub.io** → Real-time news + sentiment
- **FinBERT** → Financial domain-specific BERT model

**Key Metric — Sentiment-Return Correlation:**
- Correlation close to 0 = sentiment has no predictive value
- Correlation > 0.2 = some predictive power (rare!)
- Statistically significant at α=0.05 → p-value < 0.05

---

### 💼 Page 5 — Portfolio Optimizer
**What it does:** Find the mathematically optimal stock allocation using Modern Portfolio Theory (MPT)

**Markowitz Efficient Frontier:**
- Each point = one possible portfolio (different weight combinations)
- X-axis = Risk (volatility), Y-axis = Expected Return
- **Efficient Frontier** = the "best" portfolios for each risk level (maximum return per unit of risk)

**Key Formulas:**
- **Portfolio Return** = Σ(weight_i × return_i)
- **Portfolio Variance** = wᵀ Σ w (matrix multiplication with covariance)
- **Sharpe Ratio** = (Return − Risk-Free Rate) / Volatility

**Optimal Portfolios:**
- ⭐ **Max Sharpe** = Best risk-adjusted return
- 🛡️ **Min Volatility** = Lowest possible risk

**Monte Carlo Method:**
- Generate 2,000+ random weight combinations
- Calculate return, volatility, Sharpe for each
- Plot all → identifies the efficient frontier visually

---

### ⚠️ Page 6 — Risk Dashboard
**What it does:** Comprehensive risk measurement for a stock

**Risk Metrics Explained:**

| Metric | Formula | Interpretation |
|--------|---------|----------------|
| **VaR 95%** | 5th percentile of daily returns | "On a bad day, max loss is X%" |
| **CVaR** | Mean of returns below VaR | "When things go badly, avg loss is X%" |
| **Sharpe Ratio** | (Ret − Rf) / Vol | >1 = Good, >2 = Great, <0 = Bad |
| **Sortino Ratio** | (Ret − Rf) / Downside Vol | Like Sharpe but only penalizes downside |
| **Beta** | Cov(stock, market) / Var(market) | >1 = More volatile than market |
| **Alpha** | Excess return above CAPM prediction | Positive = Manager added value |
| **Max Drawdown** | (Trough − Peak) / Peak | Worst peak-to-trough loss |
| **Calmar Ratio** | Ann. Return / Max Drawdown | Higher = Better risk-adjusted return |

**Monte Carlo Simulation:**
- Simulates 1,000 possible future price paths
- Uses Geometric Brownian Motion: `dS = μS dt + σS dW`
- Shows 5th/50th/95th percentile outcomes

---

### 🏢 Page 7 — Fundamental Analysis
**What it does:** Analyze company financial health like a professional investor

**Valuation Ratios:**

| Ratio | Formula | Rule of Thumb |
|-------|---------|---------------|
| **P/E** | Price / Earnings per Share | S&P 500 avg ~22; <15 = cheap |
| **Forward P/E** | Price / Expected Earnings | Growth stocks have high forward P/E |
| **PEG** | P/E / Earnings Growth Rate | <1 = potentially undervalued |
| **P/S** | Market Cap / Revenue | Useful for non-profitable companies |
| **P/B** | Price / Book Value | <1 = trading below assets |
| **EV/EBITDA** | Enterprise Value / EBITDA | Acquisition valuation standard |

**Profitability Ratios:**
- **Gross Margin** = (Revenue − COGS) / Revenue → How much per $1 of sales
- **Operating Margin** = Operating Income / Revenue
- **Net Margin** = Net Income / Revenue → Bottom line profitability
- **ROE** = Net Income / Shareholders Equity → Return on owners' money
- **ROA** = Net Income / Total Assets → Efficiency of assets

**Financial Health Score:**
- 10-point checklist covering profitability, growth, valuation, and size
- Graded A–F like a report card

---

### 🧪 Page 8 — Strategy Backtesting
**What it does:** Test trading strategies on historical data to see how they would have performed

**Strategies Available:**

| Strategy | Logic | Best For |
|----------|-------|----------|
| **MA Crossover** | Buy when fast MA > slow MA | Trending markets |
| **RSI Mean Reversion** | Buy oversold (<30), sell overbought (>70) | Ranging markets |
| **MACD Crossover** | Buy when MACD > Signal line | Medium-term trends |
| **Bollinger Breakout** | Buy at lower band, sell at upper band | Volatile markets |
| **Buy & Hold** | Always invested | Long-term baseline |

**Backtest Engine:**
1. Generate signals from historical data
2. Shift signals by 1 day (cannot trade on the same bar)
3. Multiply signal by daily return → Strategy return
4. Subtract commission costs
5. Compound returns to get equity curve

**Performance Metrics:**
- **Sharpe Ratio** = Risk-adjusted return
- **Max Drawdown** = Worst loss from peak
- **Win Rate** = % of profitable trading days
- **Number of Trades** = Frequency of trading

**Common Pitfalls (Backtest Biases):**
- ⚠️ **Look-ahead bias** = Using future info to make past decisions (we avoid this with shift(1))
- ⚠️ **Survivorship bias** = Only testing stocks that still exist
- ⚠️ **Overfitting** = Parameters tuned too specifically to history

---

### 🌍 Page 9 — Market Overview & Screener
**What it does:** Real-time market pulse and custom stock screener

**Market Data Tracked:**
- Major indices: S&P 500, NASDAQ, Dow Jones, Russell 2000
- Volatility: VIX (Fear Index — >30 = fear, <20 = complacency)
- Commodities: Gold, Oil
- Crypto: Bitcoin
- Fixed income: 10-Year Treasury Yield
- Forex: EUR/USD

**Sector Rotation:**
- 11 S&P 500 sectors tracked via SPDR ETFs
- Monthly performance comparison
- Identifies which sectors are leading/lagging

**Stock Screener:**
- Screen up to 15 stocks simultaneously
- Rank by: returns, margins, P/E, volatility
- Bubble chart = visualize risk vs return vs market cap

---

## 🛠️ Technical Architecture

```
User Input (Sidebar)
        │
        ▼
Yahoo Finance API (yfinance)
        │
        ▼
Pandas DataFrame Processing
        │
    ┌───┴───────────────┐
    │                   │
Feature Engineering    Risk Metrics
(ML Page)              (Risk Page)
    │                   │
sklearn Models      scipy/numpy
    │                   │
    └───────┬───────────┘
            │
        Plotly Charts
            │
        Streamlit UI
```

---

## 📦 Key Libraries Used

| Library | Purpose |
|---------|---------|
| `streamlit` | Web app framework |
| `yfinance` | Yahoo Finance API wrapper |
| `plotly` | Interactive charts |
| `pandas` | Data manipulation |
| `numpy` | Numerical computing |
| `scikit-learn` | Machine learning models |
| `scipy` | Statistical functions |

---

## ⚡ Run Commands

```bash
# Standard run
streamlit run app.py

# Custom port
streamlit run app.py --server.port 8502

# Allow external access
streamlit run app.py --server.address 0.0.0.0

# Production mode (disable CORS warnings)
streamlit run app.py --server.enableCORS false
```

---

## 🔧 Customization

### Add Real Sentiment Data
Replace the `generate_sentiment_data()` function in Page 4 with:
```python
import requests
API_KEY = "your_newsapi_key"
url = f"https://newsapi.org/v2/everything?q={ticker}&apiKey={API_KEY}"
articles = requests.get(url).json()['articles']
```

### Add More ML Models
In Page 3, add to `models_to_train` dict:
```python
from sklearn.svm import SVR
"SVR": SVR(kernel='rbf', C=100, epsilon=0.1)
```

---

## ⚠️ Disclaimer

This project is for **educational and research purposes only**.  
Nothing here constitutes financial advice.  
Never make investment decisions based solely on model output.

---

*Built with Python 🐍 | Streamlit ⚡ | Yahoo Finance 📊*
