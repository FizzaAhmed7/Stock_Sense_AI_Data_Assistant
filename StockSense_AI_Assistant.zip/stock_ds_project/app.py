"""
📈 Stock Market Data Science Dashboard
=====================================
Main entry point for the Streamlit application.
"""

import streamlit as st

st.set_page_config(
    page_title="StockSense AI | Data Science Platform",
    page_icon="📈",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Custom CSS for professional look
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');

    html, body, [class*="css"] {
        font-family: 'Space Grotesk', sans-serif;
    }

    .main-header {
        background: linear-gradient(135deg, #0f0f23 0%, #1a1a3e 50%, #0d1117 100%);
        padding: 2rem;
        border-radius: 16px;
        margin-bottom: 2rem;
        border: 1px solid #30363d;
        text-align: center;
    }

    .main-header h1 {
        font-size: 3rem;
        font-weight: 700;
        background: linear-gradient(90deg, #58a6ff, #79c0ff, #a5d6ff);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        margin: 0;
    }

    .main-header p {
        color: #8b949e;
        font-size: 1.1rem;
        margin-top: 0.5rem;
    }

    .metric-card {
        background: #161b22;
        border: 1px solid #30363d;
        border-radius: 12px;
        padding: 1.5rem;
        text-align: center;
        transition: all 0.3s ease;
    }

    .nav-card {
        background: linear-gradient(135deg, #161b22, #1c2128);
        border: 1px solid #30363d;
        border-radius: 12px;
        padding: 1.5rem;
        margin: 0.5rem 0;
        cursor: pointer;
        transition: all 0.3s;
    }

    .nav-card:hover {
        border-color: #58a6ff;
        transform: translateX(5px);
    }

    .stButton > button {
        background: linear-gradient(135deg, #238636, #2ea043);
        color: white;
        border: none;
        border-radius: 8px;
        padding: 0.6rem 1.5rem;
        font-weight: 600;
        transition: all 0.3s;
    }

    .stButton > button:hover {
        background: linear-gradient(135deg, #2ea043, #3fb950);
        transform: translateY(-2px);
        box-shadow: 0 4px 15px rgba(46, 160, 67, 0.4);
    }

    .sidebar .sidebar-content {
        background: #0d1117;
    }

    div[data-testid="stSidebarNav"] {
        background: #0d1117;
    }

    .feature-badge {
        display: inline-block;
        background: rgba(88, 166, 255, 0.15);
        color: #58a6ff;
        padding: 0.2rem 0.7rem;
        border-radius: 20px;
        font-size: 0.8rem;
        border: 1px solid rgba(88, 166, 255, 0.3);
        margin: 0.2rem;
    }
</style>
""", unsafe_allow_html=True)

# Hero Section
st.markdown("""
<div class="main-header">
    <h1>📈 StockSense AI</h1>
    <p>Professional Stock Market Data Science Platform</p>
    <br>
    <span class="feature-badge">🤖 ML Predictions</span>
    <span class="feature-badge">📊 Technical Analysis</span>
    <span class="feature-badge">📰 Sentiment Analysis</span>
    <span class="feature-badge">⚡ Real-time Data</span>
    <span class="feature-badge">🎯 Portfolio Optimizer</span>
    <span class="feature-badge">📉 Risk Analysis</span>
</div>
""", unsafe_allow_html=True)

# Navigation Guide
st.markdown("## 🗺️ Navigate Using the Sidebar →")

col1, col2, col3 = st.columns(3)

with col1:
    st.markdown("""
    ### 📊 Analysis Pages
    - **1. Stock Explorer** — Price charts, volume, OHLC
    - **2. Technical Analysis** — RSI, MACD, Bollinger Bands
    - **3. Fundamental Analysis** — P/E, EPS, Revenue
    """)

with col2:
    st.markdown("""
    ### 🤖 AI & ML Pages
    - **4. ML Price Prediction** — LSTM & RandomForest models
    - **5. Sentiment Analysis** — News & social sentiment
    - **6. Pattern Recognition** — Chart pattern detector
    """)

with col3:
    st.markdown("""
    ### 💼 Portfolio Pages
    - **7. Portfolio Optimizer** — Markowitz optimization
    - **8. Risk Dashboard** — VaR, Sharpe, Beta
    - **9. Backtesting** — Strategy performance
    """)

# Quick Stats Row
st.markdown("---")
st.markdown("### 🔥 Quick Market Pulse")

import yfinance as yf
import pandas as pd

try:
    tickers_pulse = ["^GSPC", "^DJI", "^IXIC", "BTC-USD"]
    labels = ["S&P 500", "Dow Jones", "NASDAQ", "Bitcoin"]
    cols = st.columns(4)
    for i, (ticker, label) in enumerate(zip(tickers_pulse, labels)):
        data = yf.Ticker(ticker).history(period="2d")
        if not data.empty:
            price = data['Close'].iloc[-1]
            prev = data['Close'].iloc[-2]
            chg = ((price - prev) / prev) * 100
            delta_color = "🟢" if chg > 0 else "🔴"
            with cols[i]:
                st.metric(
                    label=f"{delta_color} {label}",
                    value=f"${price:,.2f}" if ticker != "BTC-USD" else f"${price:,.0f}",
                    delta=f"{chg:+.2f}%"
                )
except Exception as e:
    st.info("💡 Navigate to individual pages from the sidebar to begin your analysis.")

st.markdown("---")
st.markdown("""
<div style='text-align:center; color: #8b949e; font-size: 0.9rem;'>
    Built with ❤️ using Python · Streamlit · yfinance · scikit-learn · Plotly<br>
    Data sourced from Yahoo Finance API
</div>
""", unsafe_allow_html=True)
