"""
📊 Page 1: Stock Explorer
Interactive price charts with real-time data from Yahoo Finance
"""

import streamlit as st
import yfinance as yf
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

st.set_page_config(page_title="Stock Explorer", page_icon="📊", layout="wide")

st.markdown("# 📊 Stock Explorer")
st.markdown("*Fetch real-time OHLCV data from Yahoo Finance and visualize price action*")
st.markdown("---")

# ── Sidebar Controls ──────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("### ⚙️ Controls")
    ticker = st.text_input("Stock Ticker", value="AAPL", help="e.g. AAPL, TSLA, GOOGL, MSFT").upper()
    period = st.selectbox("Period", ["1mo", "3mo", "6mo", "1y", "2y", "5y"], index=3)
    chart_type = st.radio("Chart Type", ["Candlestick", "Line", "OHLC", "Area"])
    show_volume = st.checkbox("Show Volume", value=True)
    show_ma = st.checkbox("Moving Averages", value=True)
    if show_ma:
        ma_periods = st.multiselect("MA Periods", [10, 20, 50, 100, 200], default=[20, 50])

# ── Data Fetch ─────────────────────────────────────────────────────────────────
@st.cache_data(ttl=300)
def fetch_stock(ticker, period):
    stock = yf.Ticker(ticker)
    hist = stock.history(period=period)
    info = stock.info
    return hist, info

with st.spinner(f"Fetching {ticker} data..."):
    try:
        df, info = fetch_stock(ticker, period)
        if df.empty:
            st.error(f"❌ No data found for {ticker}. Please check the ticker symbol.")
            st.stop()
    except Exception as e:
        st.error(f"❌ Error: {e}")
        st.stop()

# ── Company Info ───────────────────────────────────────────────────────────────
company_name = info.get("longName", ticker)
sector = info.get("sector", "N/A")
industry = info.get("industry", "N/A")
mktcap = info.get("marketCap", 0)

st.markdown(f"## {company_name} ({ticker})")
col1, col2, col3, col4 = st.columns(4)
col1.metric("Sector", sector)
col2.metric("Industry", industry)
col3.metric("Market Cap", f"${mktcap/1e9:.2f}B" if mktcap else "N/A")
price_now = df['Close'].iloc[-1]
price_prev = df['Close'].iloc[-2]
chg_pct = (price_now - price_prev) / price_prev * 100
col4.metric("Last Price", f"${price_now:.2f}", delta=f"{chg_pct:+.2f}%")

# ── Main Chart ─────────────────────────────────────────────────────────────────
rows = 2 if show_volume else 1
row_heights = [0.7, 0.3] if show_volume else [1.0]
fig = make_subplots(rows=rows, cols=1, shared_xaxes=True,
                    row_heights=row_heights, vertical_spacing=0.05)

colors = {'up': '#26a641', 'down': '#f85149', 'volume': '#58a6ff', 'bg': '#0d1117'}

if chart_type == "Candlestick":
    fig.add_trace(go.Candlestick(
        x=df.index, open=df['Open'], high=df['High'],
        low=df['Low'], close=df['Close'], name=ticker,
        increasing_line_color='#26a641', decreasing_line_color='#f85149'
    ), row=1, col=1)
elif chart_type == "Line":
    fig.add_trace(go.Scatter(
        x=df.index, y=df['Close'], name=ticker,
        line=dict(color='#58a6ff', width=2)
    ), row=1, col=1)
elif chart_type == "OHLC":
    fig.add_trace(go.Ohlc(
        x=df.index, open=df['Open'], high=df['High'],
        low=df['Low'], close=df['Close'], name=ticker
    ), row=1, col=1)
else:  # Area
    fig.add_trace(go.Scatter(
        x=df.index, y=df['Close'], name=ticker,
        fill='tozeroy', line=dict(color='#58a6ff'),
        fillcolor='rgba(88, 166, 255, 0.1)'
    ), row=1, col=1)

# Moving Averages
ma_colors = ['#f0883e', '#a371f7', '#d2a8ff', '#ffa657', '#79c0ff']
if show_ma:
    for i, period_ma in enumerate(ma_periods):
        ma = df['Close'].rolling(period_ma).mean()
        fig.add_trace(go.Scatter(
            x=df.index, y=ma, name=f"MA{period_ma}",
            line=dict(color=ma_colors[i % len(ma_colors)], width=1.5, dash='dot')
        ), row=1, col=1)

# Volume bars
if show_volume:
    vol_colors = ['#26a641' if c >= o else '#f85149'
                  for c, o in zip(df['Close'], df['Open'])]
    fig.add_trace(go.Bar(
        x=df.index, y=df['Volume'], name="Volume",
        marker_color=vol_colors, opacity=0.7
    ), row=2, col=1)

fig.update_layout(
    template="plotly_dark",
    paper_bgcolor='#0d1117',
    plot_bgcolor='#161b22',
    height=600,
    showlegend=True,
    xaxis_rangeslider_visible=False,
    font=dict(family="Space Grotesk"),
    legend=dict(bgcolor='rgba(0,0,0,0.5)', bordercolor='#30363d')
)
fig.update_xaxes(gridcolor='#21262d', showgrid=True)
fig.update_yaxes(gridcolor='#21262d', showgrid=True)

st.plotly_chart(fig, use_container_width=True)

# ── Statistics ──────────────────────────────────────────────────────────────────
st.markdown("### 📈 Statistical Summary")
col1, col2 = st.columns(2)

with col1:
    st.markdown("**Price Statistics**")
    stats = {
        "52W High": f"${df['High'].max():.2f}",
        "52W Low": f"${df['Low'].min():.2f}",
        "Average Price": f"${df['Close'].mean():.2f}",
        "Std Deviation": f"${df['Close'].std():.2f}",
        "Daily Volatility": f"{df['Close'].pct_change().std()*100:.2f}%",
        "Ann. Volatility": f"{df['Close'].pct_change().std()*np.sqrt(252)*100:.2f}%"
    }
    st.table(pd.DataFrame(stats.items(), columns=["Metric", "Value"]).set_index("Metric"))

with col2:
    st.markdown("**Returns Distribution**")
    returns = df['Close'].pct_change().dropna() * 100
    fig2 = px.histogram(
        returns, nbins=50, title="Daily Returns (%)",
        color_discrete_sequence=['#58a6ff'],
        template="plotly_dark"
    )
    fig2.update_layout(paper_bgcolor='#0d1117', plot_bgcolor='#161b22',
                       height=300, font=dict(family="Space Grotesk"))
    st.plotly_chart(fig2, use_container_width=True)

# ── Raw Data Table ──────────────────────────────────────────────────────────────
with st.expander("📋 View Raw Data"):
    st.dataframe(df.tail(50).style.background_gradient(cmap='Blues'), use_container_width=True)
    csv = df.to_csv()
    st.download_button("⬇️ Download CSV", csv, f"{ticker}_data.csv", "text/csv")
