"""
📉 Page 2: Technical Analysis
RSI, MACD, Bollinger Bands, Stochastic, ATR, OBV indicators
"""

import streamlit as st
import yfinance as yf
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import pandas as pd
import numpy as np

st.set_page_config(page_title="Technical Analysis", page_icon="📉", layout="wide")

st.markdown("# 📉 Technical Analysis")
st.markdown("*Industry-standard indicators: RSI, MACD, Bollinger Bands, Stochastic, ATR, OBV*")
st.markdown("---")

with st.sidebar:
    st.markdown("### ⚙️ Settings")
    ticker = st.text_input("Ticker", value="AAPL").upper()
    period = st.selectbox("Period", ["3mo", "6mo", "1y", "2y"], index=2)
    indicators = st.multiselect("Indicators", 
        ["RSI", "MACD", "Bollinger Bands", "Stochastic", "ATR", "OBV", "Williams %R"],
        default=["RSI", "MACD", "Bollinger Bands"])

# ── Indicator Functions ────────────────────────────────────────────────────────
def compute_rsi(series, period=14):
    delta = series.diff()
    gain = delta.where(delta > 0, 0).rolling(period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(period).mean()
    rs = gain / loss
    return 100 - (100 / (1 + rs))

def compute_macd(series, fast=12, slow=26, signal=9):
    ema_fast = series.ewm(span=fast).mean()
    ema_slow = series.ewm(span=slow).mean()
    macd = ema_fast - ema_slow
    signal_line = macd.ewm(span=signal).mean()
    histogram = macd - signal_line
    return macd, signal_line, histogram

def compute_bollinger(series, window=20, std=2):
    ma = series.rolling(window).mean()
    std_dev = series.rolling(window).std()
    upper = ma + std * std_dev
    lower = ma - std * std_dev
    return upper, ma, lower

def compute_stochastic(df, k_period=14, d_period=3):
    low_min = df['Low'].rolling(k_period).min()
    high_max = df['High'].rolling(k_period).max()
    k = 100 * (df['Close'] - low_min) / (high_max - low_min)
    d = k.rolling(d_period).mean()
    return k, d

def compute_atr(df, period=14):
    h_l = df['High'] - df['Low']
    h_pc = abs(df['High'] - df['Close'].shift(1))
    l_pc = abs(df['Low'] - df['Close'].shift(1))
    tr = pd.concat([h_l, h_pc, l_pc], axis=1).max(axis=1)
    return tr.rolling(period).mean()

def compute_obv(df):
    obv = [0]
    for i in range(1, len(df)):
        if df['Close'].iloc[i] > df['Close'].iloc[i-1]:
            obv.append(obv[-1] + df['Volume'].iloc[i])
        elif df['Close'].iloc[i] < df['Close'].iloc[i-1]:
            obv.append(obv[-1] - df['Volume'].iloc[i])
        else:
            obv.append(obv[-1])
    return pd.Series(obv, index=df.index)

def compute_williams_r(df, period=14):
    high_max = df['High'].rolling(period).max()
    low_min = df['Low'].rolling(period).min()
    return -100 * (high_max - df['Close']) / (high_max - low_min)

# ── Fetch Data ─────────────────────────────────────────────────────────────────
@st.cache_data(ttl=300)
def get_data(ticker, period):
    return yf.Ticker(ticker).history(period=period)

with st.spinner("Computing indicators..."):
    df = get_data(ticker, period)
    if df.empty:
        st.error("❌ Invalid ticker or no data.")
        st.stop()

# ── Candlestick Base ───────────────────────────────────────────────────────────
n_subplots = 1 + len(indicators)
row_heights = [0.4] + [0.6/max(len(indicators),1)] * len(indicators)

fig = make_subplots(rows=n_subplots, cols=1, shared_xaxes=True,
                    row_heights=row_heights, vertical_spacing=0.03,
                    subplot_titles=[ticker] + indicators)

fig.add_trace(go.Candlestick(
    x=df.index, open=df['Open'], high=df['High'],
    low=df['Low'], close=df['Close'], name="Price",
    increasing_line_color='#26a641', decreasing_line_color='#f85149'
), row=1, col=1)

# Bollinger Bands on price chart
if "Bollinger Bands" in indicators:
    ub, mb, lb = compute_bollinger(df['Close'])
    fig.add_trace(go.Scatter(x=df.index, y=ub, name='BB Upper',
        line=dict(color='rgba(88,166,255,0.7)', width=1, dash='dash')), row=1, col=1)
    fig.add_trace(go.Scatter(x=df.index, y=mb, name='BB Middle',
        line=dict(color='rgba(88,166,255,0.5)', width=1)), row=1, col=1)
    fig.add_trace(go.Scatter(x=df.index, y=lb, name='BB Lower',
        line=dict(color='rgba(88,166,255,0.7)', width=1, dash='dash'),
        fill='tonexty', fillcolor='rgba(88,166,255,0.05)'), row=1, col=1)
    indicators_no_bb = [i for i in indicators if i != "Bollinger Bands"]
else:
    indicators_no_bb = indicators

# Other indicators in subplots
row_idx = 2
for ind in indicators_no_bb:
    if ind == "RSI":
        rsi = compute_rsi(df['Close'])
        fig.add_trace(go.Scatter(x=df.index, y=rsi, name='RSI',
            line=dict(color='#a371f7', width=2)), row=row_idx, col=1)
        fig.add_hline(y=70, line_dash="dash", line_color="#f85149", opacity=0.7, row=row_idx, col=1)
        fig.add_hline(y=30, line_dash="dash", line_color="#26a641", opacity=0.7, row=row_idx, col=1)
        fig.add_hrect(y0=70, y1=100, fillcolor="rgba(248,81,73,0.05)", row=row_idx, col=1)
        fig.add_hrect(y0=0, y1=30, fillcolor="rgba(38,166,65,0.05)", row=row_idx, col=1)
        row_idx += 1
    elif ind == "MACD":
        macd, signal, hist = compute_macd(df['Close'])
        colors_hist = ['#26a641' if v >= 0 else '#f85149' for v in hist]
        fig.add_trace(go.Bar(x=df.index, y=hist, name='MACD Hist',
            marker_color=colors_hist, opacity=0.7), row=row_idx, col=1)
        fig.add_trace(go.Scatter(x=df.index, y=macd, name='MACD',
            line=dict(color='#58a6ff', width=2)), row=row_idx, col=1)
        fig.add_trace(go.Scatter(x=df.index, y=signal, name='Signal',
            line=dict(color='#f0883e', width=2)), row=row_idx, col=1)
        row_idx += 1
    elif ind == "Stochastic":
        k, d = compute_stochastic(df)
        fig.add_trace(go.Scatter(x=df.index, y=k, name='%K',
            line=dict(color='#58a6ff', width=2)), row=row_idx, col=1)
        fig.add_trace(go.Scatter(x=df.index, y=d, name='%D',
            line=dict(color='#f0883e', width=2)), row=row_idx, col=1)
        fig.add_hline(y=80, line_dash="dash", line_color="#f85149", row=row_idx, col=1)
        fig.add_hline(y=20, line_dash="dash", line_color="#26a641", row=row_idx, col=1)
        row_idx += 1
    elif ind == "ATR":
        atr = compute_atr(df)
        fig.add_trace(go.Scatter(x=df.index, y=atr, name='ATR',
            line=dict(color='#ffa657', width=2)), row=row_idx, col=1)
        row_idx += 1
    elif ind == "OBV":
        obv = compute_obv(df)
        fig.add_trace(go.Scatter(x=df.index, y=obv, name='OBV',
            line=dict(color='#79c0ff', width=2),
            fill='tozeroy', fillcolor='rgba(121,192,255,0.1)'), row=row_idx, col=1)
        row_idx += 1
    elif ind == "Williams %R":
        wr = compute_williams_r(df)
        fig.add_trace(go.Scatter(x=df.index, y=wr, name='Williams %R',
            line=dict(color='#d2a8ff', width=2)), row=row_idx, col=1)
        fig.add_hline(y=-20, line_dash="dash", line_color="#f85149", row=row_idx, col=1)
        fig.add_hline(y=-80, line_dash="dash", line_color="#26a641", row=row_idx, col=1)
        row_idx += 1

fig.update_layout(
    template="plotly_dark",
    paper_bgcolor='#0d1117',
    plot_bgcolor='#161b22',
    height=200 * n_subplots,
    showlegend=True,
    xaxis_rangeslider_visible=False,
    font=dict(family="Space Grotesk"),
)
fig.update_xaxes(gridcolor='#21262d')
fig.update_yaxes(gridcolor='#21262d')
st.plotly_chart(fig, use_container_width=True)

# ── Signal Summary ─────────────────────────────────────────────────────────────
st.markdown("### 🎯 Signal Summary")
rsi_val = compute_rsi(df['Close']).iloc[-1]
macd_val, sig_val, _ = compute_macd(df['Close'])
k_val, _ = compute_stochastic(df)

signals = []
signals.append({"Indicator": "RSI (14)", "Value": f"{rsi_val:.1f}",
                 "Signal": "🔴 Overbought" if rsi_val > 70 else ("🟢 Oversold" if rsi_val < 30 else "🟡 Neutral")})
signals.append({"Indicator": "MACD", "Value": f"{macd_val.iloc[-1]:.3f}",
                 "Signal": "🟢 Bullish" if macd_val.iloc[-1] > sig_val.iloc[-1] else "🔴 Bearish"})
signals.append({"Indicator": "Stochastic %K", "Value": f"{k_val.iloc[-1]:.1f}",
                 "Signal": "🔴 Overbought" if k_val.iloc[-1] > 80 else ("🟢 Oversold" if k_val.iloc[-1] < 20 else "🟡 Neutral")})

st.dataframe(pd.DataFrame(signals).set_index("Indicator"), use_container_width=True)
