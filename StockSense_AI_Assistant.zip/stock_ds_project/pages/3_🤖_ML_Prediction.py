"""
🤖 Page 3: ML Price Prediction
Uses RandomForest + Linear Regression + Gradient Boosting to predict stock prices
"""

import streamlit as st
import yfinance as yf
import plotly.graph_objects as go
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import warnings
warnings.filterwarnings('ignore')

st.set_page_config(page_title="ML Prediction", page_icon="🤖", layout="wide")

st.markdown("# 🤖 ML Price Prediction")
st.markdown("*Train machine learning models to predict stock prices using technical features*")
st.markdown("---")

with st.sidebar:
    st.markdown("### ⚙️ ML Settings")
    ticker = st.text_input("Ticker", value="AAPL").upper()
    period = st.selectbox("Training Data", ["1y", "2y", "5y"], index=1)
    model_choice = st.selectbox("Model", ["Random Forest", "Gradient Boosting", "Ridge Regression", "All Models"])
    forecast_days = st.slider("Forecast Days", 5, 30, 10)
    test_size = st.slider("Test Size %", 10, 30, 20) / 100

# ── Feature Engineering ────────────────────────────────────────────────────────
def engineer_features(df):
    df = df.copy()
    # Price features
    df['Return_1d'] = df['Close'].pct_change(1)
    df['Return_5d'] = df['Close'].pct_change(5)
    df['Return_10d'] = df['Close'].pct_change(10)
    df['Return_21d'] = df['Close'].pct_change(21)

    # Moving Averages
    for w in [5, 10, 20, 50]:
        df[f'MA_{w}'] = df['Close'].rolling(w).mean()
        df[f'MA_ratio_{w}'] = df['Close'] / df[f'MA_{w}']

    # Volatility
    df['Volatility_10'] = df['Return_1d'].rolling(10).std()
    df['Volatility_20'] = df['Return_1d'].rolling(20).std()

    # RSI
    delta = df['Close'].diff()
    gain = delta.where(delta > 0, 0).rolling(14).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(14).mean()
    df['RSI'] = 100 - (100 / (1 + gain / loss))

    # MACD
    ema12 = df['Close'].ewm(span=12).mean()
    ema26 = df['Close'].ewm(span=26).mean()
    df['MACD'] = ema12 - ema26
    df['MACD_Signal'] = df['MACD'].ewm(span=9).mean()

    # Bollinger Band width
    ma20 = df['Close'].rolling(20).mean()
    std20 = df['Close'].rolling(20).std()
    df['BB_Width'] = (2 * std20) / ma20

    # Volume features
    df['Volume_MA10'] = df['Volume'].rolling(10).mean()
    df['Volume_ratio'] = df['Volume'] / df['Volume_MA10']

    # Price position
    df['High_Low_ratio'] = df['High'] / df['Low']
    df['Close_Open_ratio'] = df['Close'] / df['Open']

    # Target: next day close
    df['Target'] = df['Close'].shift(-1)

    return df.dropna()

@st.cache_data(ttl=300)
def get_data(ticker, period):
    return yf.Ticker(ticker).history(period=period)

with st.spinner(f"Fetching {ticker} data & engineering features..."):
    raw = get_data(ticker, period)
    if raw.empty:
        st.error("❌ No data.")
        st.stop()
    df = engineer_features(raw)

feature_cols = [c for c in df.columns if c not in ['Open', 'High', 'Low', 'Close', 'Volume', 'Target', 'Dividends', 'Stock Splits']]
X = df[feature_cols]
y = df['Target']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_size, shuffle=False)

# Scale
scaler = MinMaxScaler()
X_train_s = scaler.fit_transform(X_train)
X_test_s = scaler.transform(X_test)

# ── Train Models ────────────────────────────────────────────────────────────────
models_to_train = {
    "Random Forest": RandomForestRegressor(n_estimators=100, max_depth=8, random_state=42),
    "Gradient Boosting": GradientBoostingRegressor(n_estimators=100, max_depth=5, random_state=42),
    "Ridge Regression": Ridge(alpha=10)
}

if model_choice != "All Models":
    models_to_train = {model_choice: models_to_train[model_choice]}

results = {}
with st.spinner("Training models..."):
    for name, model in models_to_train.items():
        model.fit(X_train_s, y_train)
        preds = model.predict(X_test_s)
        results[name] = {
            "model": model,
            "preds": preds,
            "mae": mean_absolute_error(y_test, preds),
            "rmse": np.sqrt(mean_squared_error(y_test, preds)),
            "r2": r2_score(y_test, preds),
            "mape": np.mean(np.abs((y_test - preds) / y_test)) * 100
        }

# ── Metrics Display ────────────────────────────────────────────────────────────
st.markdown("### 📊 Model Performance Metrics")
metric_cols = st.columns(len(results))
for i, (name, res) in enumerate(results.items()):
    with metric_cols[i]:
        st.markdown(f"**{name}**")
        st.metric("R² Score", f"{res['r2']:.4f}")
        st.metric("MAE", f"${res['mae']:.2f}")
        st.metric("RMSE", f"${res['rmse']:.2f}")
        st.metric("MAPE", f"{res['mape']:.2f}%")

# ── Prediction Chart ───────────────────────────────────────────────────────────
st.markdown("### 📈 Actual vs Predicted Prices")

fig = go.Figure()
fig.add_trace(go.Scatter(
    x=y_test.index, y=y_test,
    name="Actual", line=dict(color='#58a6ff', width=2)
))

colors_pred = ['#26a641', '#f0883e', '#a371f7']
for i, (name, res) in enumerate(results.items()):
    fig.add_trace(go.Scatter(
        x=y_test.index, y=res['preds'],
        name=f"{name} Predicted", line=dict(color=colors_pred[i], width=1.5, dash='dash')
    ))

fig.update_layout(
    template="plotly_dark", paper_bgcolor='#0d1117', plot_bgcolor='#161b22',
    height=450, font=dict(family="Space Grotesk"),
    title=f"{ticker} — Actual vs Predicted (Test Set)"
)
fig.update_xaxes(gridcolor='#21262d')
fig.update_yaxes(gridcolor='#21262d')
st.plotly_chart(fig, use_container_width=True)

# ── Feature Importance ─────────────────────────────────────────────────────────
if "Random Forest" in results or "Gradient Boosting" in results:
    st.markdown("### 🔍 Feature Importance")
    chosen = "Random Forest" if "Random Forest" in results else "Gradient Boosting"
    importances = results[chosen]["model"].feature_importances_
    fi_df = pd.DataFrame({"Feature": feature_cols, "Importance": importances})
    fi_df = fi_df.sort_values("Importance", ascending=False).head(15)

    fig3 = go.Figure(go.Bar(
        x=fi_df["Importance"], y=fi_df["Feature"],
        orientation='h', marker_color='#58a6ff',
        marker=dict(colorscale='Blues', color=fi_df["Importance"])
    ))
    fig3.update_layout(
        template="plotly_dark", paper_bgcolor='#0d1117', plot_bgcolor='#161b22',
        height=450, font=dict(family="Space Grotesk"),
        title=f"Top 15 Features — {chosen}"
    )
    st.plotly_chart(fig3, use_container_width=True)

# ── Future Forecast ────────────────────────────────────────────────────────────
st.markdown(f"### 🔮 {forecast_days}-Day Price Forecast")
st.warning("⚠️ This is a simulation for educational purposes only. NOT financial advice.")

best_model_name = max(results, key=lambda k: results[k]['r2'])
best_model = results[best_model_name]["model"]

# Simple rolling forecast
last_features = X.iloc[-1:].copy()
future_prices = []

for _ in range(forecast_days):
    scaled = scaler.transform(last_features)
    pred = best_model.predict(scaled)[0]
    future_prices.append(pred)
    # Update features naively
    last_features['Return_1d'] = (pred - last_features['Return_1d'].values[0]) / max(last_features['Return_1d'].values[0], 0.001)

future_dates = pd.date_range(start=df.index[-1] + pd.Timedelta(days=1), periods=forecast_days, freq='B')

fig4 = go.Figure()
hist_tail = 60
fig4.add_trace(go.Scatter(
    x=df.index[-hist_tail:], y=df['Close'].iloc[-hist_tail:],
    name="Historical", line=dict(color='#58a6ff', width=2)
))
fig4.add_trace(go.Scatter(
    x=future_dates, y=future_prices,
    name=f"{best_model_name} Forecast",
    line=dict(color='#26a641', width=2, dash='dash'),
    mode='lines+markers'
))
fig4.add_vline(x=str(df.index[-1]), line_dash="dash", line_color="#f0883e")

fig4.update_layout(
    template="plotly_dark", paper_bgcolor='#0d1117', plot_bgcolor='#161b22',
    height=400, font=dict(family="Space Grotesk"),
    title=f"{ticker} — {forecast_days}-Day Forecast using {best_model_name}"
)
st.plotly_chart(fig4, use_container_width=True)
