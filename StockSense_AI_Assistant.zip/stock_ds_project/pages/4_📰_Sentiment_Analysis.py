"""
📰 Page 4: Sentiment Analysis
News sentiment scoring + correlation with price movement
"""

import streamlit as st
import yfinance as yf
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import pandas as pd
import numpy as np
import requests
from datetime import datetime, timedelta
import re

st.set_page_config(page_title="Sentiment Analysis", page_icon="📰", layout="wide")

st.markdown("# 📰 Sentiment Analysis")
st.markdown("*Analyze news sentiment and correlate with stock price movement*")
st.markdown("---")

with st.sidebar:
    st.markdown("### ⚙️ Settings")
    ticker = st.text_input("Ticker", value="AAPL").upper()
    period = st.selectbox("Period", ["1mo", "3mo", "6mo", "1y"], index=2)

# ── Simulated News Sentiment (realistic simulation) ───────────────────────────
# In production: integrate NewsAPI, Alpha Vantage News, or Finnhub

@st.cache_data(ttl=600)
def get_stock_data(ticker, period):
    return yf.Ticker(ticker).history(period=period)

@st.cache_data(ttl=600)
def get_ticker_info(ticker):
    return yf.Ticker(ticker).info

def generate_sentiment_data(df, ticker):
    """
    Realistic sentiment simulation based on price movement + noise.
    Replace with real API (NewsAPI / Alpha Vantage) for production.
    """
    np.random.seed(42)
    daily_returns = df['Close'].pct_change().fillna(0)
    
    sentiments = []
    for i, (date, ret) in enumerate(zip(df.index, daily_returns)):
        # Correlated with price but with noise
        base_sentiment = np.clip(ret * 10 + np.random.normal(0, 0.3), -1, 1)
        
        sentiment_score = float(base_sentiment)
        if sentiment_score > 0.3:
            label = "Bullish"
        elif sentiment_score < -0.3:
            label = "Bearish"
        else:
            label = "Neutral"
        
        sentiments.append({
            "Date": date,
            "Sentiment_Score": round(sentiment_score, 3),
            "Label": label,
            "Confidence": round(abs(sentiment_score) * 0.8 + np.random.uniform(0.1, 0.3), 2),
            "News_Count": np.random.randint(1, 15)
        })
    
    return pd.DataFrame(sentiments).set_index("Date")

with st.spinner("Fetching data & computing sentiment..."):
    df = get_stock_data(ticker, period)
    if df.empty:
        st.error("❌ Invalid ticker.")
        st.stop()
    info = get_ticker_info(ticker)
    sent_df = generate_sentiment_data(df, ticker)

# ── Merge ──────────────────────────────────────────────────────────────────────
merged = df[['Close', 'Volume']].join(sent_df, how='inner')
merged['Return'] = merged['Close'].pct_change()

# ── Overview Metrics ───────────────────────────────────────────────────────────
col1, col2, col3, col4 = st.columns(4)
avg_sent = merged['Sentiment_Score'].mean()
bullish_pct = (merged['Label'] == 'Bullish').mean() * 100
bearish_pct = (merged['Label'] == 'Bearish').mean() * 100
corr = merged['Sentiment_Score'].corr(merged['Return'].shift(-1))

col1.metric("Avg Sentiment", f"{avg_sent:+.3f}", delta="Positive" if avg_sent > 0 else "Negative")
col2.metric("🟢 Bullish Days", f"{bullish_pct:.1f}%")
col3.metric("🔴 Bearish Days", f"{bearish_pct:.1f}%")
col4.metric("Sentiment-Return Corr", f"{corr:.3f}")

# ── Main Sentiment Chart ───────────────────────────────────────────────────────
st.markdown("### 📊 Sentiment vs Price")
fig = make_subplots(rows=3, cols=1, shared_xaxes=True,
                    row_heights=[0.5, 0.3, 0.2], vertical_spacing=0.05,
                    subplot_titles=["Price", "Sentiment Score", "News Volume"])

fig.add_trace(go.Scatter(
    x=merged.index, y=merged['Close'], name="Price",
    line=dict(color='#58a6ff', width=2)
), row=1, col=1)

# Sentiment bars colored by direction
colors_sent = ['#26a641' if s > 0 else '#f85149' for s in merged['Sentiment_Score']]
fig.add_trace(go.Bar(
    x=merged.index, y=merged['Sentiment_Score'], name="Sentiment",
    marker_color=colors_sent, opacity=0.8
), row=2, col=1)

# Rolling sentiment
rolling_sent = merged['Sentiment_Score'].rolling(7).mean()
fig.add_trace(go.Scatter(
    x=merged.index, y=rolling_sent, name="7D MA Sentiment",
    line=dict(color='#ffa657', width=2)
), row=2, col=1)

fig.add_hline(y=0, line_color='white', opacity=0.3, row=2, col=1)

fig.add_trace(go.Bar(
    x=merged.index, y=merged['News_Count'], name="News Count",
    marker_color='#a371f7', opacity=0.7
), row=3, col=1)

fig.update_layout(
    template="plotly_dark", paper_bgcolor='#0d1117', plot_bgcolor='#161b22',
    height=650, font=dict(family="Space Grotesk"), showlegend=True
)
fig.update_xaxes(gridcolor='#21262d')
fig.update_yaxes(gridcolor='#21262d')
st.plotly_chart(fig, use_container_width=True)

# ── Sentiment Distribution ─────────────────────────────────────────────────────
col1, col2 = st.columns(2)

with col1:
    st.markdown("### 🎯 Sentiment Distribution")
    label_counts = merged['Label'].value_counts().reset_index()
    fig2 = px.pie(label_counts, values='count', names='Label',
                  color='Label',
                  color_discrete_map={'Bullish': '#26a641', 'Bearish': '#f85149', 'Neutral': '#58a6ff'},
                  template='plotly_dark')
    fig2.update_layout(paper_bgcolor='#0d1117', height=300, font=dict(family="Space Grotesk"))
    st.plotly_chart(fig2, use_container_width=True)

with col2:
    st.markdown("### 📉 Sentiment vs Next-Day Return")
    scatter_df = merged.copy()
    scatter_df['Next_Return'] = scatter_df['Return'].shift(-1) * 100
    scatter_df = scatter_df.dropna()
    fig3 = px.scatter(scatter_df, x='Sentiment_Score', y='Next_Return',
                      color='Label',
                      color_discrete_map={'Bullish': '#26a641', 'Bearish': '#f85149', 'Neutral': '#58a6ff'},
                      trendline='ols',
                      template='plotly_dark',
                      title="Sentiment → Next Day Return (%)")
    fig3.update_layout(paper_bgcolor='#0d1117', plot_bgcolor='#161b22',
                       height=300, font=dict(family="Space Grotesk"))
    st.plotly_chart(fig3, use_container_width=True)

# ── Bullish/Bearish Returns Analysis ──────────────────────────────────────────
st.markdown("### 📊 Average Return by Sentiment Label")
ret_by_sentiment = merged.groupby('Label')['Return'].agg(['mean', 'std', 'count']) * 100
ret_by_sentiment.columns = ['Avg Return (%)', 'Std Dev (%)', 'Days']
ret_by_sentiment['Avg Return (%)'] = ret_by_sentiment['Avg Return (%)'].round(3)
ret_by_sentiment['Std Dev (%)'] = ret_by_sentiment['Std Dev (%)'].round(3)

st.dataframe(ret_by_sentiment.style.background_gradient(cmap='RdYlGn', subset=['Avg Return (%)']),
             use_container_width=True)

st.info("""
💡 **About Sentiment Analysis**  
In production, replace the simulated sentiment with real data from:
- **NewsAPI** — news headlines with keyword scoring
- **Alpha Vantage** — built-in sentiment API for stocks
- **Finnhub** — real-time news sentiment feed
- **Twitter/X API** — social media sentiment with VADER / FinBERT NLP
""")
