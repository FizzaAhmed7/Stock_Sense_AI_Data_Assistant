"""
💼 Page 5: Portfolio Optimizer
Markowitz Modern Portfolio Theory — Efficient Frontier
"""

import streamlit as st
import yfinance as yf
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
import numpy as np
from scipy.optimize import minimize
import warnings
warnings.filterwarnings('ignore')

st.set_page_config(page_title="Portfolio Optimizer", page_icon="💼", layout="wide")

st.markdown("# 💼 Portfolio Optimizer")
st.markdown("*Markowitz Modern Portfolio Theory — Find the optimal allocation for max Sharpe Ratio*")
st.markdown("---")

with st.sidebar:
    st.markdown("### ⚙️ Portfolio Settings")
    default_tickers = "AAPL, MSFT, GOOGL, AMZN, TSLA"
    tickers_input = st.text_area("Tickers (comma-separated)", default_tickers)
    tickers = [t.strip().upper() for t in tickers_input.split(",") if t.strip()]
    period = st.selectbox("Data Period", ["1y", "2y", "3y", "5y"], index=1)
    n_simulations = st.slider("Monte Carlo Simulations", 500, 5000, 2000)
    risk_free = st.number_input("Risk-Free Rate (%)", value=4.5, step=0.1) / 100

# ── Fetch Data ─────────────────────────────────────────────────────────────────
@st.cache_data(ttl=600)
def fetch_prices(tickers, period):
    all_close = {}
    for t in tickers:
        try:
            df = yf.Ticker(t).history(period=period)['Close']
            if not df.empty:
                all_close[t] = df
        except:
            pass
    return pd.DataFrame(all_close).dropna()

with st.spinner(f"Fetching {len(tickers)} stocks..."):
    prices = fetch_prices(tickers, period)
    if prices.empty or prices.shape[1] < 2:
        st.error("❌ Need at least 2 valid tickers.")
        st.stop()

valid_tickers = list(prices.columns)
returns = prices.pct_change().dropna()
n_assets = len(valid_tickers)

st.success(f"✅ Loaded {n_assets} stocks: {', '.join(valid_tickers)}")

# ── Correlation Heatmap ────────────────────────────────────────────────────────
col1, col2 = st.columns([2, 1])
with col1:
    st.markdown("### 🔥 Correlation Matrix")
    corr = returns.corr()
    fig_heat = go.Figure(go.Heatmap(
        z=corr.values, x=corr.columns, y=corr.index,
        colorscale='RdYlGn', zmin=-1, zmax=1,
        text=corr.values.round(2), texttemplate="%{text}",
        showscale=True
    ))
    fig_heat.update_layout(
        template="plotly_dark", paper_bgcolor='#0d1117', plot_bgcolor='#161b22',
        height=350, font=dict(family="Space Grotesk")
    )
    st.plotly_chart(fig_heat, use_container_width=True)

with col2:
    st.markdown("### 📊 Annual Stats")
    ann_ret = returns.mean() * 252 * 100
    ann_vol = returns.std() * np.sqrt(252) * 100
    sharpe = (ann_ret/100 - risk_free) / (ann_vol/100)
    stats = pd.DataFrame({
        "Ann. Return": ann_ret.round(2).astype(str) + "%",
        "Ann. Volatility": ann_vol.round(2).astype(str) + "%",
        "Sharpe": sharpe.round(3)
    })
    st.dataframe(stats, use_container_width=True)

# ── Monte Carlo Simulation ─────────────────────────────────────────────────────
st.markdown("### 🎲 Efficient Frontier — Monte Carlo")

np.random.seed(42)
mean_returns = returns.mean()
cov_matrix = returns.cov()

sim_returns, sim_vols, sim_sharpes, sim_weights = [], [], [], []

for _ in range(n_simulations):
    w = np.random.dirichlet(np.ones(n_assets))
    p_ret = np.sum(mean_returns * w) * 252
    p_vol = np.sqrt(w.T @ (cov_matrix * 252) @ w)
    p_sharpe = (p_ret - risk_free) / p_vol
    sim_returns.append(p_ret * 100)
    sim_vols.append(p_vol * 100)
    sim_sharpes.append(p_sharpe)
    sim_weights.append(w)

sim_df = pd.DataFrame({
    "Return (%)": sim_returns,
    "Volatility (%)": sim_vols,
    "Sharpe": sim_sharpes
})

# Optimal portfolios
max_sharpe_idx = np.argmax(sim_sharpes)
min_vol_idx = np.argmin(sim_vols)

fig_frontier = go.Figure()

fig_frontier.add_trace(go.Scatter(
    x=sim_df["Volatility (%)"], y=sim_df["Return (%)"],
    mode='markers',
    marker=dict(color=sim_df["Sharpe"], colorscale='Viridis',
                size=3, opacity=0.6, showscale=True,
                colorbar=dict(title="Sharpe Ratio")),
    name="Portfolios", hovertemplate="Vol: %{x:.2f}%<br>Return: %{y:.2f}%<extra></extra>"
))

# Max Sharpe
fig_frontier.add_trace(go.Scatter(
    x=[sim_df["Volatility (%)"].iloc[max_sharpe_idx]],
    y=[sim_df["Return (%)"].iloc[max_sharpe_idx]],
    mode='markers', name="⭐ Max Sharpe",
    marker=dict(color='#f0883e', size=15, symbol='star', line=dict(color='white', width=2))
))

# Min Vol
fig_frontier.add_trace(go.Scatter(
    x=[sim_df["Volatility (%)"].iloc[min_vol_idx]],
    y=[sim_df["Return (%)"].iloc[min_vol_idx]],
    mode='markers', name="🛡️ Min Volatility",
    marker=dict(color='#58a6ff', size=15, symbol='diamond', line=dict(color='white', width=2))
))

fig_frontier.update_layout(
    template="plotly_dark", paper_bgcolor='#0d1117', plot_bgcolor='#161b22',
    height=500, font=dict(family="Space Grotesk"),
    xaxis_title="Annualized Volatility (%)",
    yaxis_title="Annualized Return (%)",
    title="Efficient Frontier — Each dot = 1 random portfolio"
)
fig_frontier.update_xaxes(gridcolor='#21262d')
fig_frontier.update_yaxes(gridcolor='#21262d')
st.plotly_chart(fig_frontier, use_container_width=True)

# ── Optimal Weights ────────────────────────────────────────────────────────────
col1, col2 = st.columns(2)

for col, idx, title, color in [
    (col1, max_sharpe_idx, "⭐ Max Sharpe Portfolio", '#f0883e'),
    (col2, min_vol_idx, "🛡️ Min Volatility Portfolio", '#58a6ff')
]:
    weights = sim_weights[idx]
    ret = sim_df["Return (%)"].iloc[idx]
    vol = sim_df["Volatility (%)"].iloc[idx]
    sharpe = sim_df["Sharpe"].iloc[idx]
    
    with col:
        st.markdown(f"### {title}")
        st.metric("Expected Return", f"{ret:.2f}%")
        st.metric("Expected Volatility", f"{vol:.2f}%")
        st.metric("Sharpe Ratio", f"{sharpe:.3f}")
        
        w_df = pd.DataFrame({"Ticker": valid_tickers, "Weight": weights})
        w_df = w_df.sort_values("Weight", ascending=False)
        fig_pie = px.pie(w_df, values='Weight', names='Ticker',
                         color_discrete_sequence=px.colors.sequential.Blues_r,
                         template='plotly_dark')
        fig_pie.update_layout(paper_bgcolor='#0d1117', height=300,
                               font=dict(family="Space Grotesk"))
        st.plotly_chart(fig_pie, use_container_width=True)
        
        w_df['Weight'] = (w_df['Weight'] * 100).round(2).astype(str) + "%"
        st.dataframe(w_df.set_index("Ticker"), use_container_width=True)

# ── Cumulative Returns ─────────────────────────────────────────────────────────
st.markdown("### 📈 Optimal Portfolio vs Equal Weight vs Individual Stocks")

max_weights = np.array(sim_weights[max_sharpe_idx])
equal_weights = np.ones(n_assets) / n_assets

opt_cum = (returns @ max_weights + 1).cumprod()
eq_cum = (returns @ equal_weights + 1).cumprod()

fig_cum = go.Figure()
for col in returns.columns:
    cum = (returns[col] + 1).cumprod()
    fig_cum.add_trace(go.Scatter(x=cum.index, y=cum, name=col,
                                  line=dict(width=1, dash='dot'), opacity=0.6))

fig_cum.add_trace(go.Scatter(x=opt_cum.index, y=opt_cum, name="⭐ Max Sharpe",
                              line=dict(color='#f0883e', width=3)))
fig_cum.add_trace(go.Scatter(x=eq_cum.index, y=eq_cum, name="Equal Weight",
                              line=dict(color='#58a6ff', width=2, dash='dash')))

fig_cum.update_layout(
    template="plotly_dark", paper_bgcolor='#0d1117', plot_bgcolor='#161b22',
    height=400, font=dict(family="Space Grotesk"),
    title="Cumulative Returns (Base = 1.0)"
)
fig_cum.update_xaxes(gridcolor='#21262d')
fig_cum.update_yaxes(gridcolor='#21262d')
st.plotly_chart(fig_cum, use_container_width=True)
