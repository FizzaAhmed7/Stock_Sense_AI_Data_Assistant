"""
⚠️ Page 6: Risk Dashboard
VaR, CVaR, Sharpe, Sortino, Beta, Maximum Drawdown analysis
"""

import streamlit as st
import yfinance as yf
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import pandas as pd
import numpy as np
from scipy import stats

st.set_page_config(page_title="Risk Dashboard", page_icon="⚠️", layout="wide")

st.markdown("# ⚠️ Risk Dashboard")
st.markdown("*Comprehensive risk metrics: VaR, CVaR, Drawdown, Sharpe, Sortino, Beta*")
st.markdown("---")

with st.sidebar:
    st.markdown("### ⚙️ Settings")
    ticker = st.text_input("Stock Ticker", value="TSLA").upper()
    benchmark = st.text_input("Benchmark", value="^GSPC")
    period = st.selectbox("Period", ["1y", "2y", "3y", "5y"], index=1)
    confidence = st.slider("VaR Confidence Level (%)", 90, 99, 95) / 100
    risk_free = st.number_input("Risk-Free Rate (%)", value=4.5) / 100

@st.cache_data(ttl=300)
def get_data(ticker, benchmark, period):
    t = yf.Ticker(ticker).history(period=period)['Close']
    b = yf.Ticker(benchmark).history(period=period)['Close']
    df = pd.DataFrame({'Stock': t, 'Benchmark': b}).dropna()
    return df

with st.spinner("Computing risk metrics..."):
    df = get_data(ticker, benchmark, period)
    if df.empty:
        st.error("❌ No data.")
        st.stop()

rets = df.pct_change().dropna()
stock_r = rets['Stock']
bench_r = rets['Benchmark']

# ── Risk Metric Functions ──────────────────────────────────────────────────────
def compute_var(returns, confidence):
    return np.percentile(returns, (1 - confidence) * 100)

def compute_cvar(returns, confidence):
    var = compute_var(returns, confidence)
    return returns[returns <= var].mean()

def compute_sharpe(returns, risk_free):
    excess = returns.mean() * 252 - risk_free
    return excess / (returns.std() * np.sqrt(252))

def compute_sortino(returns, risk_free):
    excess = returns.mean() * 252 - risk_free
    downside = returns[returns < 0].std() * np.sqrt(252)
    return excess / downside if downside > 0 else 0

def compute_max_drawdown(prices):
    roll_max = prices.expanding().max()
    dd = (prices - roll_max) / roll_max
    return dd.min(), dd

def compute_beta(stock_r, bench_r):
    covariance = np.cov(stock_r, bench_r)[0][1]
    variance = np.var(bench_r)
    return covariance / variance

def compute_calmar(prices, returns):
    ann_return = (prices.iloc[-1] / prices.iloc[0]) ** (252 / len(prices)) - 1
    max_dd, _ = compute_max_drawdown(prices)
    return ann_return / abs(max_dd) if max_dd != 0 else 0

# ── Compute All Metrics ────────────────────────────────────────────────────────
var = compute_var(stock_r, confidence)
cvar = compute_cvar(stock_r, confidence)
sharpe = compute_sharpe(stock_r, risk_free)
sortino = compute_sortino(stock_r, risk_free)
max_dd, dd_series = compute_max_drawdown(df['Stock'])
beta = compute_beta(stock_r, bench_r)
alpha = (stock_r.mean() * 252) - (risk_free + beta * (bench_r.mean() * 252 - risk_free))
calmar = compute_calmar(df['Stock'], stock_r)
ann_vol = stock_r.std() * np.sqrt(252) * 100
ann_ret = stock_r.mean() * 252 * 100
skewness = stats.skew(stock_r)
kurt = stats.kurtosis(stock_r)

# ── Metrics Display ────────────────────────────────────────────────────────────
st.markdown("### 🎯 Key Risk Metrics")
col1, col2, col3, col4, col5, col6 = st.columns(6)
col1.metric("Sharpe Ratio", f"{sharpe:.3f}", delta="Good" if sharpe > 1 else "Poor")
col2.metric("Sortino Ratio", f"{sortino:.3f}")
col3.metric("Beta", f"{beta:.3f}", delta="Defensive" if beta < 1 else "Aggressive")
col4.metric("Alpha (Ann.)", f"{alpha*100:.2f}%")
col5.metric("Max Drawdown", f"{max_dd*100:.2f}%")
col6.metric("Calmar Ratio", f"{calmar:.3f}")

col1, col2, col3, col4, col5, col6 = st.columns(6)
col1.metric(f"VaR ({int(confidence*100)}%)", f"{var*100:.2f}%", delta="Daily 1-day loss")
col2.metric("CVaR (Expected)", f"{cvar*100:.2f}%")
col3.metric("Ann. Volatility", f"{ann_vol:.2f}%")
col4.metric("Ann. Return", f"{ann_ret:.2f}%")
col5.metric("Skewness", f"{skewness:.3f}")
col6.metric("Excess Kurtosis", f"{kurt:.3f}")

# ── VaR Distribution Chart ─────────────────────────────────────────────────────
st.markdown("### 📊 Return Distribution & VaR")
fig1 = go.Figure()
fig1.add_trace(go.Histogram(x=stock_r*100, nbinsx=80, name="Returns",
                             marker_color='#58a6ff', opacity=0.7))

# VaR line
fig1.add_vline(x=var*100, line_dash="dash", line_color="#f85149",
               annotation_text=f"VaR ({int(confidence*100)}%): {var*100:.2f}%",
               annotation_position="top right")
fig1.add_vline(x=cvar*100, line_dash="dot", line_color="#ffa657",
               annotation_text=f"CVaR: {cvar*100:.2f}%",
               annotation_position="top left")

fig1.update_layout(
    template="plotly_dark", paper_bgcolor='#0d1117', plot_bgcolor='#161b22',
    height=400, font=dict(family="Space Grotesk"),
    title=f"{ticker} — Daily Return Distribution",
    xaxis_title="Daily Return (%)", yaxis_title="Frequency"
)
fig1.update_xaxes(gridcolor='#21262d')
fig1.update_yaxes(gridcolor='#21262d')
st.plotly_chart(fig1, use_container_width=True)

# ── Drawdown Chart ─────────────────────────────────────────────────────────────
col1, col2 = st.columns(2)

with col1:
    st.markdown("### 📉 Drawdown Over Time")
    fig2 = go.Figure()
    fig2.add_trace(go.Scatter(
        x=dd_series.index, y=dd_series*100,
        fill='tozeroy', name="Drawdown",
        line=dict(color='#f85149', width=1),
        fillcolor='rgba(248, 81, 73, 0.2)'
    ))
    fig2.update_layout(
        template="plotly_dark", paper_bgcolor='#0d1117', plot_bgcolor='#161b22',
        height=350, font=dict(family="Space Grotesk"),
        title="Drawdown (%)", yaxis_title="Drawdown (%)"
    )
    fig2.update_xaxes(gridcolor='#21262d')
    fig2.update_yaxes(gridcolor='#21262d')
    st.plotly_chart(fig2, use_container_width=True)

with col2:
    st.markdown("### 📈 Stock vs Benchmark")
    stock_norm = (df['Stock'] / df['Stock'].iloc[0]) * 100
    bench_norm = (df['Benchmark'] / df['Benchmark'].iloc[0]) * 100
    
    fig3 = go.Figure()
    fig3.add_trace(go.Scatter(x=df.index, y=stock_norm, name=ticker,
                               line=dict(color='#58a6ff', width=2)))
    fig3.add_trace(go.Scatter(x=df.index, y=bench_norm, name="Benchmark",
                               line=dict(color='#f0883e', width=2)))
    fig3.update_layout(
        template="plotly_dark", paper_bgcolor='#0d1117', plot_bgcolor='#161b22',
        height=350, font=dict(family="Space Grotesk"),
        title="Normalized Performance (Base=100)"
    )
    fig3.update_xaxes(gridcolor='#21262d')
    fig3.update_yaxes(gridcolor='#21262d')
    st.plotly_chart(fig3, use_container_width=True)

# ── Rolling Risk Metrics ───────────────────────────────────────────────────────
st.markdown("### 🔄 Rolling Risk Metrics (60-Day Window)")
window = 60
roll_vol = stock_r.rolling(window).std() * np.sqrt(252) * 100
roll_sharpe = (stock_r.rolling(window).mean() * 252 - risk_free) / (stock_r.rolling(window).std() * np.sqrt(252))
roll_beta = stock_r.rolling(window).cov(bench_r) / bench_r.rolling(window).var()

fig4 = make_subplots(rows=3, cols=1, shared_xaxes=True, vertical_spacing=0.05,
                     subplot_titles=["Rolling Volatility (%)", "Rolling Sharpe", "Rolling Beta"])
fig4.add_trace(go.Scatter(x=roll_vol.index, y=roll_vol, name="Vol", line=dict(color='#f85149')), row=1, col=1)
fig4.add_trace(go.Scatter(x=roll_sharpe.index, y=roll_sharpe, name="Sharpe", line=dict(color='#58a6ff')), row=2, col=1)
fig4.add_hline(y=0, line_dash="dash", line_color="white", opacity=0.3, row=2, col=1)
fig4.add_trace(go.Scatter(x=roll_beta.index, y=roll_beta, name="Beta", line=dict(color='#a371f7')), row=3, col=1)
fig4.add_hline(y=1, line_dash="dash", line_color="white", opacity=0.3, row=3, col=1)

fig4.update_layout(
    template="plotly_dark", paper_bgcolor='#0d1117', plot_bgcolor='#161b22',
    height=550, font=dict(family="Space Grotesk"), showlegend=False
)
fig4.update_xaxes(gridcolor='#21262d')
fig4.update_yaxes(gridcolor='#21262d')
st.plotly_chart(fig4, use_container_width=True)

# ── Monte Carlo VaR ────────────────────────────────────────────────────────────
st.markdown("### 🎲 Monte Carlo Risk Simulation")
mc_days = st.slider("Simulation Days", 10, 252, 30)
n_sims = 1000

mu = stock_r.mean()
sigma = stock_r.std()
last_price = df['Stock'].iloc[-1]

np.random.seed(42)
sim_rets = np.random.normal(mu, sigma, (mc_days, n_sims))
price_paths = last_price * np.exp(np.cumsum(sim_rets, axis=0))

fig5 = go.Figure()
for i in range(min(200, n_sims)):
    fig5.add_trace(go.Scatter(
        y=price_paths[:, i], mode='lines',
        line=dict(color='rgba(88,166,255,0.05)', width=1),
        showlegend=False
    ))

pct_5 = np.percentile(price_paths, 5, axis=1)
pct_50 = np.percentile(price_paths, 50, axis=1)
pct_95 = np.percentile(price_paths, 95, axis=1)

fig5.add_trace(go.Scatter(y=pct_95, name="95th percentile", line=dict(color='#26a641', width=2)))
fig5.add_trace(go.Scatter(y=pct_50, name="Median", line=dict(color='#ffa657', width=3, dash='dash')))
fig5.add_trace(go.Scatter(y=pct_5, name="5th percentile", line=dict(color='#f85149', width=2)))

fig5.update_layout(
    template="plotly_dark", paper_bgcolor='#0d1117', plot_bgcolor='#161b22',
    height=400, font=dict(family="Space Grotesk"),
    title=f"{ticker} — {n_sims} Monte Carlo Paths ({mc_days} days)",
    yaxis_title="Price ($)"
)
fig5.update_xaxes(gridcolor='#21262d', title="Days")
fig5.update_yaxes(gridcolor='#21262d')
st.plotly_chart(fig5, use_container_width=True)

terminal_prices = price_paths[-1, :]
st.markdown(f"""
| Scenario | Price | Return |
|---|---|---|
| Best Case (95th pct) | ${np.percentile(terminal_prices, 95):.2f} | {(np.percentile(terminal_prices, 95)/last_price-1)*100:+.2f}% |
| Median (50th pct) | ${np.percentile(terminal_prices, 50):.2f} | {(np.percentile(terminal_prices, 50)/last_price-1)*100:+.2f}% |
| Worst Case (5th pct) | ${np.percentile(terminal_prices, 5):.2f} | {(np.percentile(terminal_prices, 5)/last_price-1)*100:+.2f}% |
| Current Price | ${last_price:.2f} | — |
""")
