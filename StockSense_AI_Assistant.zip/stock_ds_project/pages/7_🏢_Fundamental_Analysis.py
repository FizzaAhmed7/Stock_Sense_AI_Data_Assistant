"""
🏢 Page 7: Fundamental Analysis
P/E, EPS, Revenue, margins, financial health scoring
"""

import streamlit as st
import yfinance as yf
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
import numpy as np

st.set_page_config(page_title="Fundamental Analysis", page_icon="🏢", layout="wide")

st.markdown("# 🏢 Fundamental Analysis")
st.markdown("*Deep dive into company financials: P/E, EPS, Revenue, Margins, Balance Sheet*")
st.markdown("---")

with st.sidebar:
    st.markdown("### ⚙️ Settings")
    ticker = st.text_input("Ticker", value="AAPL").upper()
    compare_tickers = st.text_area("Compare With (comma-separated)", "MSFT, GOOGL")
    compare_list = [t.strip().upper() for t in compare_tickers.split(",") if t.strip()]

@st.cache_data(ttl=1800)
def get_fundamentals(ticker):
    t = yf.Ticker(ticker)
    info = t.info
    try:
        income = t.financials
        balance = t.balance_sheet
        cashflow = t.cashflow
    except:
        income, balance, cashflow = pd.DataFrame(), pd.DataFrame(), pd.DataFrame()
    return info, income, balance, cashflow

with st.spinner(f"Loading {ticker} fundamentals..."):
    info, income, balance, cashflow = get_fundamentals(ticker)

# ── Company Overview ───────────────────────────────────────────────────────────
st.markdown(f"## {info.get('longName', ticker)} ({ticker})")
st.markdown(f"*{info.get('longBusinessSummary', 'No description available.')[:400]}...*")

col1, col2, col3, col4 = st.columns(4)
mkt_cap = info.get('marketCap', 0)
col1.metric("Market Cap", f"${mkt_cap/1e9:.2f}B" if mkt_cap else "N/A")
col2.metric("Sector", info.get('sector', 'N/A'))
col3.metric("Employees", f"{info.get('fullTimeEmployees', 0):,}" if info.get('fullTimeEmployees') else "N/A")
col4.metric("Country", info.get('country', 'N/A'))

st.markdown("---")

# ── Valuation Metrics ──────────────────────────────────────────────────────────
st.markdown("### 💰 Valuation Metrics")

valuation_metrics = {
    "P/E Ratio (TTM)": info.get('trailingPE', 'N/A'),
    "Forward P/E": info.get('forwardPE', 'N/A'),
    "PEG Ratio": info.get('pegRatio', 'N/A'),
    "Price/Sales": info.get('priceToSalesTrailing12Months', 'N/A'),
    "Price/Book": info.get('priceToBook', 'N/A'),
    "EV/EBITDA": info.get('enterpriseToEbitda', 'N/A'),
    "EV/Revenue": info.get('enterpriseToRevenue', 'N/A'),
    "Dividend Yield": f"{info.get('dividendYield', 0)*100:.2f}%" if info.get('dividendYield') else "N/A",
}

cols = st.columns(4)
for i, (metric, val) in enumerate(valuation_metrics.items()):
    if isinstance(val, float):
        val = round(val, 2)
    cols[i % 4].metric(metric, str(val))

# ── Financial Performance ──────────────────────────────────────────────────────
st.markdown("### 📊 Financial Performance Metrics")

perf_metrics = {
    "Revenue (TTM)": f"${info.get('totalRevenue', 0)/1e9:.2f}B" if info.get('totalRevenue') else "N/A",
    "Gross Profit": f"${info.get('grossProfits', 0)/1e9:.2f}B" if info.get('grossProfits') else "N/A",
    "EBITDA": f"${info.get('ebitda', 0)/1e9:.2f}B" if info.get('ebitda') else "N/A",
    "Net Income": f"${info.get('netIncomeToCommon', 0)/1e9:.2f}B" if info.get('netIncomeToCommon') else "N/A",
    "Gross Margin": f"{info.get('grossMargins', 0)*100:.1f}%" if info.get('grossMargins') else "N/A",
    "Operating Margin": f"{info.get('operatingMargins', 0)*100:.1f}%" if info.get('operatingMargins') else "N/A",
    "Profit Margin": f"{info.get('profitMargins', 0)*100:.1f}%" if info.get('profitMargins') else "N/A",
    "ROE": f"{info.get('returnOnEquity', 0)*100:.1f}%" if info.get('returnOnEquity') else "N/A",
    "ROA": f"{info.get('returnOnAssets', 0)*100:.1f}%" if info.get('returnOnAssets') else "N/A",
    "Revenue Growth": f"{info.get('revenueGrowth', 0)*100:.1f}%" if info.get('revenueGrowth') else "N/A",
    "Earnings Growth": f"{info.get('earningsGrowth', 0)*100:.1f}%" if info.get('earningsGrowth') else "N/A",
    "EPS (TTM)": f"${info.get('trailingEps', 'N/A')}",
}

cols = st.columns(4)
for i, (metric, val) in enumerate(perf_metrics.items()):
    cols[i % 4].metric(metric, str(val))

# ── Historical Financials ──────────────────────────────────────────────────────
if not income.empty:
    st.markdown("### 📈 Income Statement Trend")
    try:
        rev_row = 'Total Revenue' if 'Total Revenue' in income.index else income.index[0]
        ni_row = 'Net Income' if 'Net Income' in income.index else None
        gp_row = 'Gross Profit' if 'Gross Profit' in income.index else None
        
        fig_income = go.Figure()
        
        if rev_row in income.index:
            rev_data = income.loc[rev_row].dropna() / 1e9
            fig_income.add_trace(go.Bar(x=[str(d.year) for d in rev_data.index], y=rev_data.values,
                                         name="Revenue ($B)", marker_color='#58a6ff', opacity=0.8))
        
        if gp_row and gp_row in income.index:
            gp_data = income.loc[gp_row].dropna() / 1e9
            fig_income.add_trace(go.Bar(x=[str(d.year) for d in gp_data.index], y=gp_data.values,
                                         name="Gross Profit ($B)", marker_color='#26a641', opacity=0.8))
        
        if ni_row and ni_row in income.index:
            ni_data = income.loc[ni_row].dropna() / 1e9
            fig_income.add_trace(go.Bar(x=[str(d.year) for d in ni_data.index], y=ni_data.values,
                                         name="Net Income ($B)", marker_color='#a371f7', opacity=0.8))
        
        fig_income.update_layout(
            template="plotly_dark", paper_bgcolor='#0d1117', plot_bgcolor='#161b22',
            height=350, font=dict(family="Space Grotesk"), barmode='group',
            title="Annual Financials ($B)"
        )
        fig_income.update_xaxes(gridcolor='#21262d')
        fig_income.update_yaxes(gridcolor='#21262d')
        st.plotly_chart(fig_income, use_container_width=True)
    except Exception as e:
        st.info(f"Chart unavailable: {e}")

# ── Financial Health Score ─────────────────────────────────────────────────────
st.markdown("### 🏥 Financial Health Score")
score = 0
max_score = 10
scores = []

checks = [
    ("Profitable (Net Margin > 5%)", info.get('profitMargins', 0) > 0.05),
    ("Revenue Growth > 5%", info.get('revenueGrowth', 0) > 0.05),
    ("Gross Margin > 30%", info.get('grossMargins', 0) > 0.30),
    ("ROE > 10%", info.get('returnOnEquity', 0) > 0.10),
    ("P/E < 40 (Reasonable)", 0 < info.get('trailingPE', 999) < 40),
    ("PEG < 2 (Fair Value)", 0 < info.get('pegRatio', 999) < 2),
    ("Pays Dividend", bool(info.get('dividendYield', 0))),
    ("Operating Margin > 10%", info.get('operatingMargins', 0) > 0.10),
    ("Positive EPS", info.get('trailingEps', -1) > 0),
    ("Market Cap > $10B (Large Cap)", info.get('marketCap', 0) > 10e9),
]

for label, passed in checks:
    scores.append({"Criterion": label, "Pass": "✅" if passed else "❌"})
    if passed:
        score += 1

col1, col2 = st.columns([1, 2])
with col1:
    pct = score / max_score * 100
    color = '#26a641' if pct >= 70 else ('#ffa657' if pct >= 50 else '#f85149')
    grade = "A" if pct >= 80 else ("B" if pct >= 70 else ("C" if pct >= 60 else ("D" if pct >= 50 else "F")))
    st.markdown(f"""
    <div style='text-align:center; padding:2rem; background:#161b22; border-radius:12px; border: 2px solid {color};'>
        <div style='font-size:4rem; font-weight:700; color:{color};'>{grade}</div>
        <div style='font-size:1.5rem; color:{color};'>{score}/{max_score}</div>
        <div style='color:#8b949e;'>Health Score</div>
    </div>
    """, unsafe_allow_html=True)

with col2:
    st.dataframe(pd.DataFrame(scores).set_index("Criterion"), use_container_width=True)

# ── Peer Comparison ────────────────────────────────────────────────────────────
if compare_list:
    st.markdown("### 🔄 Peer Comparison")
    all_tickers = [ticker] + compare_list[:3]
    peer_data = []
    
    with st.spinner("Loading peer data..."):
        for t in all_tickers:
            try:
                info_t = yf.Ticker(t).info
                peer_data.append({
                    "Ticker": t,
                    "P/E": round(info_t.get('trailingPE', 0), 2),
                    "P/S": round(info_t.get('priceToSalesTrailing12Months', 0), 2),
                    "Gross Margin %": round(info_t.get('grossMargins', 0) * 100, 1),
                    "Net Margin %": round(info_t.get('profitMargins', 0) * 100, 1),
                    "ROE %": round(info_t.get('returnOnEquity', 0) * 100, 1),
                    "Rev Growth %": round(info_t.get('revenueGrowth', 0) * 100, 1),
                    "Mkt Cap ($B)": round(info_t.get('marketCap', 0) / 1e9, 2),
                })
            except:
                pass
    
    if peer_data:
        peer_df = pd.DataFrame(peer_data).set_index("Ticker")
        st.dataframe(peer_df.style.background_gradient(cmap='RdYlGn'), use_container_width=True)
