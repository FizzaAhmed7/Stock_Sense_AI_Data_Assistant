"""
🧪 Page 8: Strategy Backtesting
Test trading strategies on historical data with full performance metrics
"""

import streamlit as st
import yfinance as yf
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import pandas as pd
import numpy as np

st.set_page_config(page_title="Backtesting", page_icon="🧪", layout="wide")

st.markdown("# 🧪 Strategy Backtesting")
st.markdown("*Test trading strategies on historical data — MA Crossover, RSI, MACD, Bollinger*")
st.markdown("---")

with st.sidebar:
    st.markdown("### ⚙️ Backtest Settings")
    ticker = st.text_input("Ticker", value="AAPL").upper()
    period = st.selectbox("Data Period", ["1y", "2y", "3y", "5y"], index=2)
    strategy = st.selectbox("Strategy", [
        "MA Crossover", "RSI Mean Reversion", "MACD Crossover",
        "Bollinger Breakout", "Buy & Hold"
    ])
    initial_capital = st.number_input("Initial Capital ($)", value=10000, step=1000)
    
    st.markdown("### Strategy Parameters")
    if strategy == "MA Crossover":
        fast_ma = st.slider("Fast MA", 5, 50, 20)
        slow_ma = st.slider("Slow MA", 20, 200, 50)
    elif strategy == "RSI Mean Reversion":
        rsi_period = st.slider("RSI Period", 5, 30, 14)
        rsi_buy = st.slider("Buy Level", 10, 40, 30)
        rsi_sell = st.slider("Sell Level", 60, 90, 70)
    elif strategy == "MACD Crossover":
        macd_fast = st.slider("Fast EMA", 5, 20, 12)
        macd_slow = st.slider("Slow EMA", 15, 50, 26)
        macd_signal = st.slider("Signal EMA", 5, 15, 9)
    elif strategy == "Bollinger Breakout":
        bb_window = st.slider("BB Window", 10, 50, 20)
        bb_std = st.slider("BB Std Dev", 1.0, 3.0, 2.0)
    
    commission = st.number_input("Commission (%)", value=0.1, step=0.05) / 100

# ── Data Fetch ─────────────────────────────────────────────────────────────────
@st.cache_data(ttl=300)
def get_data(ticker, period):
    return yf.Ticker(ticker).history(period=period)

with st.spinner("Running backtest..."):
    df = get_data(ticker, period)
    if df.empty:
        st.error("❌ No data.")
        st.stop()
    df = df[['Open', 'High', 'Low', 'Close', 'Volume']].copy()

# ── Signal Generation ──────────────────────────────────────────────────────────
df['Signal'] = 0  # 1=Buy, -1=Sell, 0=Hold

if strategy == "MA Crossover":
    df['MA_fast'] = df['Close'].rolling(fast_ma).mean()
    df['MA_slow'] = df['Close'].rolling(slow_ma).mean()
    df['Signal'] = np.where(df['MA_fast'] > df['MA_slow'], 1, -1)

elif strategy == "RSI Mean Reversion":
    delta = df['Close'].diff()
    gain = delta.where(delta > 0, 0).rolling(rsi_period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(rsi_period).mean()
    rsi = 100 - (100 / (1 + gain / loss))
    df['RSI'] = rsi
    df['Signal'] = np.where(rsi < rsi_buy, 1, np.where(rsi > rsi_sell, -1, 0))

elif strategy == "MACD Crossover":
    ema_fast = df['Close'].ewm(span=macd_fast).mean()
    ema_slow = df['Close'].ewm(span=macd_slow).mean()
    macd = ema_fast - ema_slow
    signal_line = macd.ewm(span=macd_signal).mean()
    df['MACD'] = macd
    df['Signal_Line'] = signal_line
    df['Signal'] = np.where(macd > signal_line, 1, -1)

elif strategy == "Bollinger Breakout":
    ma = df['Close'].rolling(bb_window).mean()
    std = df['Close'].rolling(bb_window).std()
    df['BB_Upper'] = ma + bb_std * std
    df['BB_Lower'] = ma - bb_std * std
    df['Signal'] = np.where(df['Close'] < df['BB_Lower'], 1,
                   np.where(df['Close'] > df['BB_Upper'], -1, 0))

elif strategy == "Buy & Hold":
    df['Signal'] = 1

# ── Backtest Engine ────────────────────────────────────────────────────────────
df['Position'] = df['Signal'].shift(1).fillna(0)
df['Daily_Return'] = df['Close'].pct_change()
df['Strategy_Return'] = df['Position'] * df['Daily_Return']

# Apply commission on trades
df['Trade'] = df['Position'].diff().abs()
df['Commission_Cost'] = df['Trade'] * commission
df['Strategy_Return_Net'] = df['Strategy_Return'] - df['Commission_Cost']

# Portfolio Value
df['Strategy_Value'] = initial_capital * (1 + df['Strategy_Return_Net']).cumprod()
df['BnH_Value'] = initial_capital * (1 + df['Daily_Return']).cumprod()

# ── Performance Metrics ────────────────────────────────────────────────────────
strat_total = (df['Strategy_Value'].iloc[-1] / initial_capital - 1) * 100
bnh_total = (df['BnH_Value'].iloc[-1] / initial_capital - 1) * 100
strat_ann = df['Strategy_Return_Net'].mean() * 252 * 100
strat_vol = df['Strategy_Return_Net'].std() * np.sqrt(252) * 100
sharpe = strat_ann / strat_vol if strat_vol > 0 else 0

# Drawdown
roll_max = df['Strategy_Value'].expanding().max()
drawdown = (df['Strategy_Value'] - roll_max) / roll_max
max_dd = drawdown.min() * 100

n_trades = int(df['Trade'].sum() / 2)
win_days = (df['Strategy_Return_Net'] > 0).sum()
total_days = (df['Strategy_Return_Net'] != 0).sum()
win_rate = win_days / total_days * 100 if total_days > 0 else 0

# ── Metrics Display ────────────────────────────────────────────────────────────
st.markdown("### 📊 Backtest Results")
col1, col2, col3, col4, col5, col6 = st.columns(6)
col1.metric("Strategy Return", f"{strat_total:.2f}%",
            delta=f"{strat_total-bnh_total:+.2f}% vs B&H")
col2.metric("Buy & Hold Return", f"{bnh_total:.2f}%")
col3.metric("Sharpe Ratio", f"{sharpe:.3f}")
col4.metric("Max Drawdown", f"{max_dd:.2f}%")
col5.metric("Win Rate", f"{win_rate:.1f}%")
col6.metric("# Trades", n_trades)

col1, col2, col3, col4 = st.columns(4)
col1.metric("Ann. Return", f"{strat_ann:.2f}%")
col2.metric("Ann. Volatility", f"{strat_vol:.2f}%")
col3.metric("Final Value", f"${df['Strategy_Value'].iloc[-1]:,.0f}")
col4.metric("Total Commissions", f"${df['Commission_Cost'].sum()*initial_capital:.2f}")

# ── Equity Curve ───────────────────────────────────────────────────────────────
st.markdown("### 📈 Equity Curve")
fig = make_subplots(rows=3, cols=1, shared_xaxes=True, row_heights=[0.5, 0.25, 0.25],
                    vertical_spacing=0.04, subplot_titles=["Portfolio Value", "Drawdown", "Signal"])

fig.add_trace(go.Scatter(x=df.index, y=df['Strategy_Value'], name=strategy,
                          line=dict(color='#26a641', width=2)), row=1, col=1)
fig.add_trace(go.Scatter(x=df.index, y=df['BnH_Value'], name="Buy & Hold",
                          line=dict(color='#58a6ff', width=2, dash='dash')), row=1, col=1)

fig.add_trace(go.Scatter(x=drawdown.index, y=drawdown*100, name="Drawdown",
                          fill='tozeroy', line=dict(color='#f85149', width=1),
                          fillcolor='rgba(248,81,73,0.2)'), row=2, col=1)

signal_colors = ['#26a641' if s == 1 else ('#f85149' if s == -1 else '#8b949e')
                 for s in df['Position']]
fig.add_trace(go.Bar(x=df.index, y=df['Position'], name="Position",
                      marker_color=signal_colors, opacity=0.7), row=3, col=1)

fig.update_layout(
    template="plotly_dark", paper_bgcolor='#0d1117', plot_bgcolor='#161b22',
    height=650, font=dict(family="Space Grotesk"), showlegend=True
)
fig.update_xaxes(gridcolor='#21262d')
fig.update_yaxes(gridcolor='#21262d')
st.plotly_chart(fig, use_container_width=True)

# ── Monthly Returns Heatmap ────────────────────────────────────────────────────
st.markdown("### 🗓️ Monthly Returns Heatmap")
monthly = df['Strategy_Return_Net'].resample('M').sum() * 100
monthly_df = monthly.reset_index()
monthly_df.columns = ['Date', 'Return']
monthly_df['Year'] = monthly_df['Date'].dt.year
monthly_df['Month'] = monthly_df['Date'].dt.strftime('%b')

pivot = monthly_df.pivot(index='Year', columns='Month', values='Return')
month_order = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
               'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
pivot = pivot.reindex(columns=[m for m in month_order if m in pivot.columns])

fig_heat = go.Figure(go.Heatmap(
    z=pivot.values, x=pivot.columns, y=pivot.index,
    colorscale='RdYlGn', zmid=0,
    text=pivot.values.round(1), texttemplate="%{text}%",
    showscale=True
))
fig_heat.update_layout(
    template="plotly_dark", paper_bgcolor='#0d1117',
    height=300, font=dict(family="Space Grotesk"),
    title="Monthly Returns (%)"
)
st.plotly_chart(fig_heat, use_container_width=True)

# ── Trade Log ──────────────────────────────────────────────────────────────────
with st.expander("📋 Trade Log (Position Changes)"):
    trades = df[df['Trade'] > 0][['Close', 'Position', 'Strategy_Return_Net']].copy()
    trades.columns = ['Price', 'Position After', 'Day Return Net']
    trades['Direction'] = trades['Position After'].apply(lambda x: '🟢 BUY' if x > 0 else '🔴 SELL')
    st.dataframe(trades.tail(50), use_container_width=True)

st.info("⚠️ **Disclaimer:** Past performance does not guarantee future results. This is for educational purposes only.")
