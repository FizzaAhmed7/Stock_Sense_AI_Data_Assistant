"""
🌍 Page 9: Market Overview & Stock Screener
Real-time market pulse, sector heatmap, and screener
"""

import streamlit as st
import yfinance as yf
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
import numpy as np

st.set_page_config(page_title="Market Overview", page_icon="🌍", layout="wide")

st.markdown("# 🌍 Market Overview & Stock Screener")
st.markdown("*Real-time market pulse, sector performance, and custom stock screener*")
st.markdown("---")

# ── Market Indices ─────────────────────────────────────────────────────────────
INDICES = {
    "S&P 500": "^GSPC",
    "NASDAQ": "^IXIC",
    "Dow Jones": "^DJI",
    "Russell 2000": "^RUT",
    "VIX (Fear)": "^VIX",
    "Gold": "GC=F",
    "Oil (WTI)": "CL=F",
    "Bitcoin": "BTC-USD",
    "10Y Treasury": "^TNX",
    "EUR/USD": "EURUSD=X"
}

@st.cache_data(ttl=120)
def get_market_data(symbols_dict):
    results = {}
    for name, symbol in symbols_dict.items():
        try:
            data = yf.Ticker(symbol).history(period="5d")
            if not data.empty and len(data) >= 2:
                price = data['Close'].iloc[-1]
                prev = data['Close'].iloc[-2]
                chg_pct = (price - prev) / prev * 100
                chg_abs = price - prev
                results[name] = {"price": price, "change": chg_abs, "change_pct": chg_pct}
        except:
            pass
    return results

st.markdown("### 🌡️ Global Market Pulse")
with st.spinner("Loading market data..."):
    market = get_market_data(INDICES)

cols = st.columns(5)
for i, (name, data) in enumerate(market.items()):
    p = data['price']
    chg = data['change_pct']
    emoji = "🟢" if chg > 0 else "🔴"
    fmt = f"${p:,.2f}" if "USD" not in name and "Treasury" not in name else f"{p:.2f}"
    cols[i % 5].metric(f"{emoji} {name}", fmt, delta=f"{chg:+.2f}%")

# ── Sector Performance ─────────────────────────────────────────────────────────
SECTOR_ETFS = {
    "Technology": "XLK",
    "Healthcare": "XLV",
    "Financials": "XLF",
    "Energy": "XLE",
    "Consumer Disc.": "XLY",
    "Consumer Staples": "XLP",
    "Industrials": "XLI",
    "Materials": "XLB",
    "Real Estate": "XLRE",
    "Utilities": "XLU",
    "Communication": "XLC",
}

st.markdown("### 🏭 Sector Performance (1 Month)")

@st.cache_data(ttl=600)
def get_sector_performance():
    perf = {}
    for sector, etf in SECTOR_ETFS.items():
        try:
            d = yf.Ticker(etf).history(period="1mo")
            if not d.empty:
                ret = (d['Close'].iloc[-1] / d['Close'].iloc[0] - 1) * 100
                perf[sector] = round(ret, 2)
        except:
            pass
    return perf

with st.spinner("Loading sector data..."):
    sector_perf = get_sector_performance()

if sector_perf:
    sec_df = pd.DataFrame(list(sector_perf.items()), columns=["Sector", "Return (%)"])
    sec_df = sec_df.sort_values("Return (%)", ascending=True)
    
    fig_sector = go.Figure(go.Bar(
        x=sec_df["Return (%)"], y=sec_df["Sector"],
        orientation='h',
        marker_color=['#26a641' if v > 0 else '#f85149' for v in sec_df["Return (%)"]],
        text=[f"{v:+.2f}%" for v in sec_df["Return (%)"]],
        textposition='outside'
    ))
    fig_sector.update_layout(
        template="plotly_dark", paper_bgcolor='#0d1117', plot_bgcolor='#161b22',
        height=400, font=dict(family="Space Grotesk"),
        title="Sector ETF 1-Month Return (%)",
        xaxis_title="Return (%)"
    )
    fig_sector.update_xaxes(gridcolor='#21262d')
    st.plotly_chart(fig_sector, use_container_width=True)

# ── Stock Screener ─────────────────────────────────────────────────────────────
st.markdown("### 🔍 Stock Screener")
st.markdown("Analyze a list of stocks and rank them by your criteria")

PRESETS = {
    "FAANG+": "AAPL, MSFT, GOOGL, AMZN, META, NVDA, TSLA",
    "Financials": "JPM, BAC, GS, MS, WFC, C, BRK-B",
    "Healthcare": "JNJ, UNH, PFE, ABBV, MRK, TMO, ABT",
    "Energy": "XOM, CVX, COP, SLB, EOG, MPC, VLO",
    "Custom": ""
}

preset = st.selectbox("Preset Group", list(PRESETS.keys()))
if preset == "Custom":
    tickers_input = st.text_input("Enter Tickers (comma-separated)", "AAPL, MSFT, GOOGL")
else:
    tickers_input = PRESETS[preset]

tickers = [t.strip().upper() for t in tickers_input.split(",") if t.strip()]

if st.button("🚀 Run Screener", type="primary"):
    @st.cache_data(ttl=600)
    def screen_stocks(tickers):
        results = []
        for ticker in tickers[:15]:  # limit to 15
            try:
                info = yf.Ticker(ticker).info
                hist = yf.Ticker(ticker).history(period="1y")
                if hist.empty:
                    continue
                
                ret_1m = (hist['Close'].iloc[-1] / hist['Close'].iloc[-21] - 1) * 100 if len(hist) > 21 else None
                ret_3m = (hist['Close'].iloc[-1] / hist['Close'].iloc[-63] - 1) * 100 if len(hist) > 63 else None
                ret_1y = (hist['Close'].iloc[-1] / hist['Close'].iloc[0] - 1) * 100
                vol = hist['Close'].pct_change().std() * np.sqrt(252) * 100
                
                results.append({
                    "Ticker": ticker,
                    "Price": round(info.get('currentPrice', info.get('regularMarketPrice', 0)), 2),
                    "Mkt Cap ($B)": round(info.get('marketCap', 0) / 1e9, 1),
                    "P/E": round(info.get('trailingPE', 0), 1),
                    "Gross Margin %": round(info.get('grossMargins', 0) * 100, 1),
                    "Net Margin %": round(info.get('profitMargins', 0) * 100, 1),
                    "Rev Growth %": round(info.get('revenueGrowth', 0) * 100, 1),
                    "1M Return %": round(ret_1m, 2) if ret_1m else None,
                    "3M Return %": round(ret_3m, 2) if ret_3m else None,
                    "1Y Return %": round(ret_1y, 2),
                    "Ann. Vol %": round(vol, 2),
                })
            except Exception as e:
                pass
        return results

    with st.spinner(f"Screening {len(tickers)} stocks..."):
        screen_results = screen_stocks(tickers)
    
    if screen_results:
        screen_df = pd.DataFrame(screen_results).set_index("Ticker")
        
        sort_by = st.selectbox("Sort By", list(screen_df.columns), index=list(screen_df.columns).index("1Y Return %"))
        ascending = st.checkbox("Ascending", value=False)
        screen_df = screen_df.sort_values(sort_by, ascending=ascending)
        
        st.dataframe(
            screen_df.style
                .background_gradient(cmap='RdYlGn', subset=['1Y Return %', '3M Return %', '1M Return %'])
                .background_gradient(cmap='RdYlGn', subset=['Net Margin %', 'Gross Margin %', 'Rev Growth %'])
                .format({
                    "Price": "${:.2f}",
                    "Mkt Cap ($B)": "{:.1f}",
                    "P/E": "{:.1f}",
                    "Gross Margin %": "{:.1f}%",
                    "Net Margin %": "{:.1f}%",
                    "Rev Growth %": "{:.1f}%",
                    "1M Return %": "{:+.2f}%",
                    "3M Return %": "{:+.2f}%",
                    "1Y Return %": "{:+.2f}%",
                    "Ann. Vol %": "{:.2f}%",
                }),
            use_container_width=True
        )
        
        # CSV download
        csv = screen_df.to_csv()
        st.download_button("⬇️ Download Screener Results", csv, "screener_results.csv", "text/csv")
        
        # Bubble Chart
        st.markdown("### 🫧 Risk-Return Bubble Chart")
        plot_df = screen_df.reset_index().dropna(subset=['Ann. Vol %', '1Y Return %'])
        if not plot_df.empty:
            fig_bubble = px.scatter(
                plot_df, x='Ann. Vol %', y='1Y Return %',
                text='Ticker', size='Mkt Cap ($B)',
                color='Net Margin %',
                color_continuous_scale='Viridis',
                template='plotly_dark',
                title="Risk vs Return (bubble size = Market Cap)"
            )
            fig_bubble.update_traces(textposition='top center')
            fig_bubble.update_layout(
                paper_bgcolor='#0d1117', plot_bgcolor='#161b22',
                height=500, font=dict(family="Space Grotesk")
            )
            fig_bubble.update_xaxes(gridcolor='#21262d', title="Annual Volatility (%)")
            fig_bubble.update_yaxes(gridcolor='#21262d', title="1Y Return (%)")
            st.plotly_chart(fig_bubble, use_container_width=True)
    else:
        st.warning("No data retrieved. Check tickers and try again.")
